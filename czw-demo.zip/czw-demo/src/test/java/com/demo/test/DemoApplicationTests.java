package com.demo.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    private StringDealUtils stringDealUtils;

    @Test
    void getNoMoreThanThreeIdenticalCharacterTest() {
        String finalResult = stringDealUtils.getNoMoreThanThreeIdenticalCharacter("aabcccbbad");
        System.out.println("final result:"+finalResult);
    }

    @Test
    void getReplaceThreeIdenticalCharacterTest() {
        String finalResult = stringDealUtils.getReplaceThreeIdenticalCharacter("abcccbad");
        System.out.println("final result:"+finalResult);
    }

}
