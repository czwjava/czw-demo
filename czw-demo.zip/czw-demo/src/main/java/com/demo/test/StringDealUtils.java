package com.demo.test;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

/**
 * @description: StringDealUtils
 * @author: caizhangwei
 * @date: 2024/4/25 14:55
 */
@Component
public class StringDealUtils {

    public static final String regex = "^[a-z]+$";

    public String getNoMoreThanThreeIdenticalCharacter(String strs){
        Pattern pattern = compile(regex);
        if (!pattern.matcher(strs).matches()) {
            return "strs is not a-z, please re-enter!";
        }
        StringBuilder sb = new StringBuilder(strs);
        boolean removed = true;

        while (removed) {
            removed = false;
            int count = 1;

            for (int i = 1; i < sb.length(); i++) {
                char c = sb.charAt(i);
                if (c == sb.charAt(i - 1)) {
                    count++;
                } else {
                    if (count >= 3) {
                        sb.delete(i - count, i);
                        removed = true;
                        break;
                    }
                    count = 1;
                }
            }

            if (count >= 3 && sb.length() == count) {
                sb.delete(0, sb.length());
                removed = false;
            }

            if (removed){
                System.out.println(sb);
            }
        }

        return sb.toString();

    }


    public String getReplaceThreeIdenticalCharacter(String strs){
        Pattern pattern = compile(regex);
        if (!pattern.matcher(strs).matches()) {
            return "strs is not a-z, please re-enter!";
        }
        StringBuilder sb = new StringBuilder(strs);
        boolean removed = true;

        while (removed) {
            removed = false;
            int count = 1;

            for (int i = 1; i < sb.length(); i++) {
                char c = sb.charAt(i);
                if (c == sb.charAt(i - 1)) {
                    count++;
                } else {
                    if (count >= 3) {

                        String replacementStr = "";
                        CharSequence charSequence = "";
                        if (i - count != 0) {
                            charSequence = sb.subSequence(i - count, i);
                            replacementStr = String.valueOf(sb.charAt(i - count - 1));
                        }
                        sb.replace(i - count, i, replacementStr);
                        String str = ", "+ charSequence.toString() + " is replaced by " + replacementStr;
                        System.out.println(sb+(StringUtils.hasText(replacementStr)?str:""));
                        removed = true;
                        break;
                    }
                    count = 1;
                }
            }

            if (count >= 3 && sb.length() == count) {

                removed = false;
            }

        }

        return sb.toString();

    }
}
